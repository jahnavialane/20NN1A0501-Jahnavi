# estimation-of-business-expenses2

dashboard 1     link https://public.tableau.com/views/dashboard1_16960477000680/EXPENSESBREAKDOWNINTDIVERSEBUSINESSCOSTS?:language=en-US&:display_count=n&:origin=viz_share_link

dashboard 2     link https://public.tableau.com/views/dashboard2_16960477547920/BUSINESSEXPENDITUREOVERVIEW?:language=en-US&:display_count=n&:origin=viz_share_link

dashboard 3     link https://public.tableau.com/views/dashboard3_16960478015310/EXPENSESINSIGHT?:language=en-US&:display_count=n&:origin=viz_share_link

story 1         link https://public.tableau.com/views/story1_16960474640250/Story1?:language=en-US&:display_count=n&:origin=viz_share_link

story 2         link https://public.tableau.com/views/story2_16960475089750/Story2?:language=en-US&:display_count=n&:origin=viz_share_link

video demonstration link   https://drive.google.com/file/d/1p2grHlSWtrUR2Pa99uGH1RxeMSJh6Yop/view?usp=drivesdk
